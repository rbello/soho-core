<?php

if (PHP_SAPI === 'cli') {
	
	// Enable color interface
	// http://pueblo.sourceforge.net/doc/manual/ansi_color_codes.html
	ini_set('cli_server.color', true);

	// On met un niveau d'erreur adapté
	error_reporting(E_ALL ^ E_DEPRECATED ^ E_WARNING ^ E_NOTICE);
	
	// Load Plug API
	require_once dirname(__FILE__) . '/lib/plug-lib.php';
	
	// Load Soho CLI API
	require_once SOHOPLUG_BASE . '/lib/cli-api.php';
	
	// Load CLI API
	require_once SOHOPLUG_BASE . '/lib/plug-cli.php';
		
	// Init API
	$cli = new Soho_Plug_CLI();
	
	// Config
	$cli->allowIdentityAuto = false;
	$cli->allowIdentityOverride = false;
	$cli->setStylesEnabled(true);

	// Execute query
	$cli->exec(implode(' ', $argv));

	// Return result code
	exit($cli->result['returnCode']);
	
}

?>