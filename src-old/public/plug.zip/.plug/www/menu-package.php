<?php

// On vérifie que l'argument r soit présent
if (!isset($_REQUEST['r'])) {
	echo '<div class="error fatal">Invalid request...</div>';
	exit();
}

// On recherche le package
$package = Soho_Plug::getPackageByFullname($_REQUEST['r']);

// Package non trouvé
if (!$package) {
	echo '<div class="error fatal">Package not found</div>';
	exit();
}

// Titre de la page
echo '<h1>';
if ($package['package.repository']) {
	echo '<a href="?p=repository&r=">'.htmlspecialchars($package['package.repository']).'</a> / ';
}
echo '<a href="?p=package&r='.urlencode($_REQUEST['r']).'">'.htmlspecialchars($package['package.namespace'] . '.' . $package['package.name']).'</a>';
echo '</h1>';

?>

<ul class="tabs">
	<li><a href="?p=package&r=<?php echo urlencode($_REQUEST['r']); ?>" <?php if ($_REQUEST['p'] == 'package') echo 'class="selected" ' ?>>Overview</a></li>
	<li><a href="?p=sources&r=<?php echo urlencode($_REQUEST['r']); ?>" <?php if ($_REQUEST['p'] == 'sources') echo 'class="selected" ' ?>>Sources</a></li>
	<li><a href="?p=changelog&r=<?php echo urlencode($_REQUEST['r']); ?>"<?php if ($_REQUEST['p'] == 'changelog') echo 'class="selected" ' ?>>Changelog</a></li>
	<li><a href="?p=build&r=<?php echo urlencode($_REQUEST['r']); ?>"<?php if ($_REQUEST['p'] == 'build') echo 'class="selected" ' ?>>Build</a>
<?php

if (is_array($package['build.targets']) && sizeof($package['build.targets']) > 0) {
	echo '<ul><li>';
	foreach ($package['build.targets'] as $target => $desc) {
		echo '<a href="?p=build&r='.urlencode($_REQUEST['r']).'&t='.urlencode($target).'#bottom" title="'.htmlspecialchars($desc).'">'.htmlspecialchars($target).'</a>';
	}
	echo '<li></ul>';
}

?>
	</li>
	<li><a href="?p=commits&r=<?php echo urlencode($_REQUEST['r']); ?>"<?php if ($_REQUEST['p'] == 'commits' || $_REQUEST['p'] == 'commit') echo 'class="selected" ' ?>>Revisions</a></li>
</ul>
