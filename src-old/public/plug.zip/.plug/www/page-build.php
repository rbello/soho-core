<?php

include 'menu-package.php';

$buildfile = SOHOPLUG_WORKSPACE . $package['package.folder'] . '/build.xml';

?>

<form action="?p=build&r=<?php echo urlencode($_REQUEST['r']); ?>" method="post">

<div class="box clearfix">
<?php

// Executer une task
if (isset($_REQUEST['t']) && is_file($buildfile)) {
	
	class PlugListener implements OctoPHPusListener {

		public function octophpusConsoleEvent($message) {
			echo htmlspecialchars($message) . "<br />";
		}
		
	}
	
	echo '<pre>';
	
	$o = new OctoPHPus();
	
	$o->addListener(new PlugListener());
	
	$o->executeBuildXML(
		$buildfile,
		$_REQUEST['t']
	);
	
	echo '</pre><span id="bottom"></span>';
	
}

// Affichage de l'éditeur
else {
	// Enregistrement du fichier
	if (isset($_POST['save'])) {
		print_r($_POST);
	}
	if (!is_file($buildfile)) {
		echo '<div class="error warning">This project has no buildfile.</div>';
	}
	echo '<div id="build-editor">'.(is_file($buildfile) ? htmlspecialchars(file_get_contents($buildfile)) : '').'</div>';
	echo '<p style="text-align:right;margin-top:10px"><input type="submit" value="Save buildfile" name="save" class="button" /></p>';
	echo '<script>';
	include SOHOPLUG_WWW_BASE . "/resources/ajaxorg.ACE/ace.js";
	include SOHOPLUG_WWW_BASE . "/resources/ajaxorg.ACE/mode-xml.js";
	echo ';$(function () {
		var editor = ace.edit("build-editor");
		editor.getSession().setMode("ace/mode/xml");
		editor.focus();
	});';
	echo '</script>';
}

?>
</div>

</form>