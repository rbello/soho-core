<?php

define('SOHOPLUG_WWW_BASE', dirname(__FILE__));
define('SOHOPLUG_WWW_RESOURCES', dirname(__FILE__) . '/resources');

require_once SOHOPLUG_WWW_BASE . '/../lib/plug-lib.php';

?><!DOCTYPE html>
<html lang="fr">
   <head>
	<meta charset="utf-8" />
	<title>SohoPlug</title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<style media="all" rel="stylesheet" type="text/css"><?php include SOHOPLUG_WWW_RESOURCES . '/style.css'; ?></style>
	<script src="//code.jquery.com/jquery-1.7.2.min.js"></script>
	<script>
	SohoPlug=(function ($) {

		// Le local storage est obligatoire
		if (!localStorage) {
			alert('SohoPlug Fatal Error: localStorage is not supported on your browser');
			return null;
		}

		// Informations de session par défaut
		var session = {
			logged: false,
			expires: 0,
			username: null
		};

		// Composants de l'UI
		var ui = {
			topmenu: null,
			loginform: null,
			overlay: null
		};

		// Document ready
		$(function () {
			SohoPlug.initUI();
			SohoPlug.updateUI();
		});

		// Interface publique
		return {
			initUI: function () {
				ui.topmenu = $('body > header > div > .menu');
				ui.loginform = $('body > #form-auth');
				ui.overlay = $('body > #overlay');
				
				$('#authstatus a:not([href])', ui.topmenu).bind('click', function (e) {
					e.preventDefault();
					ui.loginform.show();
					var login = $('#login_field', ui.loginform);
					if (login.val() != "") {
						$('#password_field', ui.loginform).focus();
					}
					else {
						login.focus();
					}
					ui.overlay.show();
					return false;
				});

				$('div.title a', ui.loginform).bind('click', function (e) {
					e.preventDefault();
					ui.loginform.hide();
					ui.overlay.hide();
					return false;
				});
				
			},
			updateUI: function () {
				
			}
		};
		
	})(jQuery);
	</script>
	<script>
	/**
	 * Quicksearch + Quickaction
	 * v1.5 @ evolya.fr
	 **/
	function quickSearch(q) {
		$('#search').val(q).keyup();
	}
	$(function () {
		// Quicksearch
		$('#search')
		.keyup(function (e) {
			var v = jQuery.trim($(this).val()).toLowerCase();
			if (v.length > 0) {
				$('[qs]').each(function () {
					if ($(this).attr('qs').toLowerCase().match(v)) {
						$(this).show();
					}
					else {
						$(this).hide();
					}
				});
			}
			else {
				$('[qs]').show();
			}
		})

		// Quickaction
		.keydown(function (e) {
			// Ctrl + Enter override quickaction
			if (e.keyCode === 13 && e.ctrlKey) {
				form = $(this).closest('form');
				if (form.size() === 1) {
					form.submit();
				}
				return true;
			}
			if (e.keyCode === 13) { // Enter
				if (jQuery.trim($(this).val()) == '') {
					return false;
				}
				v = $('.[qs]:visible');
				if (v.size() === 1) {
					url = v.attr('qa');
					if (url && url.length > 0) {
						// cette portion de code permet de restituer le contexte de l'execution
						if (url.substr(0, 11) === 'javascript:') {
							e = v.get(0);
							e.qstmp = function (d) { eval(d); };
							e.qstmp(url.substr(11));
							e.qstmp = null;
						}
						else {
							document.location.href = url;
						}
						e.preventDefault();
						return false;
					}
				}
			}
			return true;
		});
	});
	</script>
   </head>
   <body>
   
<?php

if (isset($_GET['m']) && $_GET['m'] == 'auth' && isset($_POST['login']) && isset($_POST['password'])) {
	
	$r = Soho_Plug::login($_POST['login'], $_POST['password']);
	
	if ($r !== true) {
		echo '<div id="noticeArea"><p class="viewport"><b>Error</b>: '.htmlspecialchars($r).'</p></div>';
	}
	
}

else if (isset($_GET['logout'])) {
	Soho_Plug::logout();
}

?>

	<header>
		<div class="viewport">
			<a class="logo" href="?">SohoPlug</a>
			<ul class="menu">
				<li id="authstatus"><?php echo Soho_Plug::isLogged() ? '<a href="?logout">'.htmlspecialchars(Soho_Plug::getCurrentUser()).' (logout)</a>' : '<a>Sign in</a>'; ?></li>
			</ul>
			<div class="search"><input type="search" id="search" placeholder="Search..." /></div>
		</div>
	</header>

	<section rel="main" class="viewport clearfix">
<?php

$page = isset($_REQUEST['p']) ? str_replace(array('.', "\\", "/", '~'), array('-', '_', '_', '-'), trim($_REQUEST['p'])) : 'workspace';

if (is_file(SOHOPLUG_WWW_BASE . "/page-$page.php")) {
	include SOHOPLUG_WWW_BASE . "/page-$page.php";
}
else {
	echo '<div class="error fatal">This is not the page you are looking for...</div>';
}

?>
	</section>

	<footer class="clearfix">
		<div class="viewport">
			<ul>
				<h4>Configuration</h4>
				<li><a href="?p=install">Installation</a></li>
			</ul>
			<ul>
				<h4>SoHo</h4>
				<li><a href="http://soho.evolya.fr/">About</a></li>
				<li><a href="http://soho.evolya.fr/support/">Support</a></li>
				<li><a href="http://soho.evolya.fr/getit/">Update</a></li>
			</ul>
		</div>
	</footer>
	
	
	<form accept-charset="UTF-8" action="<?php
	
	$uri = $_SERVER['REQUEST_URI'];
	echo htmlspecialchars($uri);
	if (strpos($uri, '&m=auth') === false && strpos($uri, '?m=auth') === false) {
		echo (strpos($uri, '?') === false ? '?' : '&') . 'm=auth';
	}
	
	  ?>" method="post" id="form-auth">
		<input name="authenticity_token" type="hidden" value="QlcGGRbpb4roKII1lxAO/P+31oCoJ+mdwmhKCk5IASE=" />
		<div class="title">Sign in <a>X</a></div>
		<div class="formbody">
	        <label for="login_field">
	          Username<br>
	          <input autocapitalize="off" autofocus="autofocus" class="text" id="login_field" name="login" tabindex="1" type="text" value="<?php echo htmlspecialchars(Soho_Plug::getConfig('Session', 'Username')); ?>" />
	        </label>
	        <label for="password_field">
	          Password
	          <br>
	          <input autocomplete="disabled" class="text" id="password_field" name="password" tabindex="2" type="password" value="" />
	        </label>
	        <label class="submit_btn">
	          <input name="submit" tabindex="3" type="submit" value="Sign in" class="button" />
	        </label>
        </div>
	</form>

	<div id="overlay"></div>
	
  </body>
</html>
