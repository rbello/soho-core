<?php

include 'menu-package.php';

?>

<div class="box">
<a href="<?php echo urlencode($_REQUEST['r']); ?>" class="button" id="browse">Browse</a>
</div>

<div class="box last">
<?php

// Description
if (isset($package['build.properties']['project.description'])) {
	echo '<div class="normal">'.$package['build.properties']['project.description'].'</div>';
}

?>	
</div>
<script>
$(function () {
	$('#browse').focus();
});
</script>
