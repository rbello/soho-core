<?php

include 'menu-package.php';

?>

<div class="box">
	<p style="float: right">
		<a href="?p=commit&r=<?php echo urlencode($_REQUEST['r']); ?>" class="button">Commit</a>
		<a href="?p=update&r=<?php echo urlencode($_REQUEST['r']); ?>" class="button">Update</a>
		<a href="<?php echo urlencode($_REQUEST['r']); ?>" class="button" id="browse">Browse</a>
	</p>
	<p>Sources</p>
	<p>...</p>
</div>
<div class="box last">

</div>
