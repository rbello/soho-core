<?php

include 'menu-package.php';

$changelogfile = SOHOPLUG_WORKSPACE . $package['package.folder'] . '/CHANGELOG.txt';

?>

<form action="?p=changelog&r=<?php echo urlencode($_REQUEST['r']); ?>" method="post" id="form-editor">

<div class="box clearfix">

	<p style="float:right"><input type="submit" value="Save changelog" name="save" class="button" /></p>

	<p>Current version: <input type="text" class="textfield" value="<?php echo htmlspecialchars($package['package.version']); ?>" /> <input type="submit" value="Change" class="button" name="chversion" />
	
	<?php
	
	if (isset($_POST['save']) && isset($_POST['contents'])) {
		if (file_put_contents($changelogfile, $_POST['contents'])) {
			echo '<span class="success">File saved!</span>';
		}
		else {
			echo '<span class="failure">Error while saving file...</span>';
		}
	}
	
	
	?>
	
	
	</p>

</div>

<div class="box last clearfix">
	<div id="changelog-editor"><?php echo is_file($changelogfile) ? htmlspecialchars(file_get_contents($changelogfile)) : ''; ?></div>
	<textarea name="contents" id="changelog-contents" style="display:none"></textarea>	
</div>

</form>

<script>
<?php
include SOHOPLUG_WWW_BASE . "/resources/ajaxorg.ACE/ace.js";
?>
$(function () {
	var editor = ace.edit("changelog-editor");
	editor.focus();
	$('#form-editor').bind('submit', function (e) {
		$('#changelog-contents').text(editor.getSession().getValue());
	});
});
</script>

