
<ul class="tabs">
	<li><a href="?p=workspace" class="selected">Workspace</a></li>
	<li><a href="?p=repositories">Repositories</a></li>
	<li><a href="https://workshop.evolya.fr/" target="_blank">Connect</a></li>
</ul>

<table class="tables packages">
	<thead>
		<tr>
			<th>Package name</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
<?php

foreach (Soho_Plug::getWorkspacePackagesList() as $package) {

	$url = '?p=package&r='.urlencode($package['package.namespace'] . '.' . $package['package.name']);

	echo '<tr qs="'.htmlspecialchars($package['package.name']).'" qa="'.$url.'" type="package">';
	echo '<td><a href="'.$url.'">'.htmlspecialchars($package['package.namespace'] . '.' . $package['package.name']).'</a></td>';
	echo '<td></td>';
	echo '</tr>';

}

?>
	</tbody>
</table>

<script>
$(function () {
	$('#search').focus();
});
</script>
