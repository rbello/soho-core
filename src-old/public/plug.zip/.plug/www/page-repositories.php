
<ul class="tabs">
	<li><a href="?p=workspace">Workspace</a></li>
	<li><a href="?p=repositories" class="selected">Repositories</a></li>
	<li><a href="https://workshop.evolya.fr/" target="_blank">Connect</a></li>
</ul>

<div class="box">
	<p>Server: <strong><?php echo htmlspecialchars(Soho_Plug::getServerURL('host')); ?></strong> / Repository: <strong><?php echo htmlspecialchars(Soho_Plug::getConfig('Repository', 'Name')); ?></strong></p>
</div>

<?php

if (!Soho_Plug::isLogged()) {
	
	echo '<div class="error warning">You are not connected. Please <a onclick="$(\'#authstatus a\').click()">sign in</a> first.</div>';
	
	return;
	
}

?>

<table class="tables repositories">
	<thead>
		<tr>
			<th>Repository</th>
			<th>URL</th>
			<th>Identity</th>
		</tr>
	</thead>
	<tbody>
<?php



?>
	</tbody>
</table>

<script>
$(function () {
	$('#search').focus();
});
</script>
