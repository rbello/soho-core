
<ul class="tabs">
	<li><a href="?p=workspace">Workspace</a></li>
	<li><a href="?p=repositories">Repositories</a></li>
	<li><a href="https://workshop.evolya.fr/" target="_blank">Connect</a></li>
</ul>

<div class="box normal">

	<h2>Installation</h2>
	
	<h3>Plug</h3>
	
	<p><pre>plug install plug</pre></p>
	
	<h3>PHP-CLI</h3>
	
	<p><pre>plug install php-cli</pre></p>
	
	<h3>LAMP</h3>
	
	<p><pre>plug install lamp</pre></p>
	
	<h3>Chrome</h3>
	
	<p><pre>plug install chrome</pre></p>
	
	<h3>SASS</h3>
	
	<p><pre>plug install sass</pre></p>
	
	<h3>Doxygen</h3>
	
	<p><pre>plug install doxygen</pre></p>

</div>

<script>
$(function () {
	$('#search').focus();
});
</script>
