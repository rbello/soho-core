<?php

include 'menu-package.php';

?>

<div class="box">
	<form id="form-commit">
		<label for="message_field">
			Message<br />
			<textarea autocapitalize="off" autofocus="autofocus" class="text" id="message_field" name="message" tabindex="1" placeholder="Enter a short message to describe this commit."></textarea>
        </label>
        <br />
        <label for="tags_field">
			Tags :
			<input autocapitalize="off" class="text" id="tags_field" name="tags" tabindex="2" type="text" value="" placeholder="Tags, separated by comas." />
        </label>
        <p style="text-align:right;margin:8px 8px 0 0"><input type="submit" class="button" value="Submit" tabindex="3" /></p>
	</form>
</div>