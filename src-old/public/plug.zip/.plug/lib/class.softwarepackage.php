<?php

class Soho_SoftwarePackage implements Soho_Serializable, ArrayAccess {

	/**
	 * Configuration du package.
	 * @var mixed[]
	 */
	protected $config = array();

	/**
	 * (non-PHPdoc)
	 * @see Soho_Serializable::getSerializableUID()
	 */
	public function getSerializableUID() {
		return
			$this->config['package.repository'] . '/' .
			$this->config['package.namespace'] . '.' .
			$this->config['package.name'];
	}

	/**
	 * Constructeur de la classe.
	 *
	 * @param mixed[] $config
	 * @throws WGFilesIOException Si le répertoire du package n'est pas lisible.
	 */
	public function __construct(array $config) {

		// Ainsi que la configuration
		$this->config = array_merge($this->config, $config);

		// On vérifie que le répertoire du package existe bien
		if (!is_dir($this->config['package.realpath'])) {
			throw new WGFilesIOException();
		}

		// Récupére les informations du package dans le fichier de build
		$this->retreiveBuildFileData();

		// Recupére les informations sur les fichiers du package.
		$this->retreiveFilesData();

		// Récupére les informations du projet eclipse.
		$this->retreiveEclipseProjectData();

		// Recupérer les icônes
		$this->retreiveIconsData();

	}

	/**
	 * Recupére les informations sur les icônes du projet, et enregistre les données dans
	 * la variable $this->config.
	 */
	public function retreiveIconsData() {

		$dir = $this->config['package.realpath'];

		// On liste les fichiers icônes valides
		$icons = array_merge(
			glob("$dir/logo*.png"),
			glob("$dir/icon*.jpg")
		);
		
		// Aucune icône
		if (sizeof($icons) < 1) return;

		foreach ($icons as $icon) {
			$info = getimagesize($icon);
			if (is_array($info)) {
				$this->config['icon.' . $info[0] . 'x' . $info[1]] = array(
					image_type_to_mime_type($info[2]),
					$icon
				);
			}
		}

	}

	/**
	 * Recupére les informations sur les fichiers, et enregistre les données dans
	 * la variable $this->config.
	 *
	 * @return void
	 */
	public function retreiveFilesData() {
		$gitignore = array();
		$this->config = array_merge(
			self::seekFilesData($this->config['package.realpath'], $gitignore),
			$this->config
		);
	}

	/**
	 * Récupére les informations du package dans le fichier de build, et enregistre
	 * les données dans la variable $this->config.
	 *
	 * @return boolean OK
	 * @return null Erreur
	 */
	public function retreiveBuildFileData() {

		// Chemin vers le fichier de build
		$buildfile = $this->config['package.realpath'] . 'build.xml';

		// Le fichier de build n'existe pas
		if (!is_file($buildfile)) {
			return false;
		}

		// On détermine le chemin absolue vers le fichier de build
		$realpath = realpath($buildfile);

		// Avant de charger OctoPHPus, on désactive sa gestion du CLI
		if (!defined('OCTOPHPUS_NO_CLI')) {
			define('OCTOPHPUS_NO_CLI', true);
		}

		try {
				
			// On instancie le builder
			$o = new OctoPHPus();
				
			// On recupère les cibles de build
			$this->config['build.targets'] = $o->getTargetsInBuildXML($realpath);
				
			// Le nom du projet
			$this->config['package.projectname'] = $o->getProjectName();
				
			// Les properties du ficher de build
			$this->config['build.properties'] = $o->getProperties();
				
			// Status du projet
			if (isset($this->config['build.properties']['project.status'])) {
				$status = explode(',', $this->config['build.properties']['project.status']);
				foreach ($status as &$s) {
					$s = trim($s);
				}
				$this->config['package.status'] = $status;
			}
				
			// Tout c'est bien passé
			return true;

		}
		catch (Exception $ex) {
				
			// En cas d'erreur, on renvoi NULL pour indiquer qu'il y a eu un soucis
			return null;
		}

	}

	/**
	 * Recupére les informations sur le projet eclipse, et enregistre les données dans
	 * la variable $this->config.
	 *
	 * @return void
	 */
	public function retreiveEclipseProjectData() {

		// Fichier .buildpath
		$this->retreiveEclipseBuildpathData();

	}

	/**
	 * Recupére les informations sur le fichier .buildpath produit par eclipse, et enregistre
	 * les données dans la variable $this->config.
	 *
	 * @return boolean
	 */
	public function retreiveEclipseBuildpathData() {

		// Chemin vers le fichier de buildpath
		$buildpathfile = $this->config['package.realpath'] . '.buildpath';

		// Le fichier de buildpath n'existe pas
		if (!is_file($buildpathfile)) {
			return false;
		}

		// On tente de parser le document
		$xml = @simplexml_load_file(realpath($buildpathfile));

		// Erreur
		if (!is_object($xml)) {
			return false;
		}

		// On prépare un tableau pour les éléments du buildpath
		$this->config['package.buildpath'] = array();

		// On parcours les entrées du fichier XML
		foreach ($xml->buildpathentry as $pe) {
				
			// On évite les entrées qui ne consernent pas les chemins vers les
			// fichiers sources.
			if ($pe['kind'] != 'src') continue;
				
			// On prépare une entrée dans le buildpath
			$entry = array(
				'kind' => 'src',
				'path' => '' . $pe['path'],
			);
				
			// Inclusions et exclusions
			if (isset($pe['including'])) {
				$entry['including'] = explode('|', $pe['including']);
			}
			if (isset($pe['excluding'])) {
				$entry['excluding'] = explode('|', $pe['excluding']);
			}

			// On ajoute l'entrée au buildpath
			$this->config['package.buildpath'][] = $entry;
				
		}

		// Nettoyage
		unset($xml);

		// On indique que la tâche a pu être réalisée correctement
		return true;

	}

	/**
	 *
	 * @param string $path
	 * @param mixed[] $data
	 * @throws WGFilesIOException
	 */
	public static function seekFilesData($path, &$gitignore = array(), &$data = array(
			'files.totalsize' => 0,
			'files.lastatime' => 0,
			'files.lastctime' => 0,
			'files.lastmtime' => 0,
			'files.extensions' => array(),
			'files.list' => array()
	)) {
	
		// On ne suit pas les liens!
		if (is_link($path)) {
			return $data;
		}
		
		// Application des règles d'ignore
		if (sizeof($gitignore) > 0) {
			// On parcours les règles des fichiers ignorés
			foreach ($gitignore as $rule) {
				// La comparaison se fait avec fnmatch
				if (fnmatch($rule, $path)) {
					//echo "GIT IGNORE: $path (rule: $rule)\n";
					return $data;
				}
			}
		}

		// Récursion pour les répertoires
		if (is_dir($path)) {

			$list = scandir($path);

			if ($list === false) {
				throw new WGFilesIOException("Unable to read directory: $path");
			}

			// On retire le '.' et le '..'
			array_shift($list);
			array_shift($list);

			// On parcours les sous-éléments
			foreach ($list as $file) {

				self::seekFilesData("$path/$file", $gitignore, $data);

			}

			return $data;

		}
		
		// Il s'agit d'un fichier .gitignore : on va le parser pour
		// complèter la liste des fichiers ignorés
		if (is_array($gitignore) && basename($path) == '.gitignore') {
			// Lecture du fichier gitignore
			$fg = file_get_contents($path);
			if ($fg) {
				// Explosion en lignes
				$fg = explode("\n", $fg);
				// Chaque ligne est traitée
				foreach ($fg as $fl) {
					$fl = trim($fl);
					// Lignes vides ou de commentaires : ignorées
					if ($fl == '' || substr($fl, 0, 1) == '#') {
						continue;
					}
					// On garde les directives ignore
					$gitignore[] = dirname($path) . "/$fl";
					//echo "GIT ADD: ".dirname($path)."/$fl\n";
				}
			}
			unset($fg, $fl);
		}

		// On détermine l'extension
		$ext = max(strrpos($path, '.'), strrpos($path, '/'));
		$ext = $ext === false ? '' : substr($path, $ext + 1);

		// On incrémente le compteur du type d'extension
		$data['files.extensions'][$ext] = 1 + (array_key_exists($ext, $data['files.extensions']) ? $data['files.extensions'][$ext] : 0);

		// On incrémente le taille globale du répertoire
		$data['files.totalsize'] += filesize($path);

		// On met à jour les dates
		$data['files.lastatime'] = max($data['files.lastatime'], fileatime($path));
		$data['files.lastctime'] = max($data['files.lastctime'], filectime($path));
		$data['files.lastmtime'] = max($data['files.lastmtime'], filemtime($path));

		// On rajoute le chemin dans la liste
		//$data['files.list'][$path] = $path;
		
		return $data;

	}

	public function __sleep() {
		return array('config');
	}

	public function __wakeup() {
		
	}

	/**
	 * Indique si une position existe dans un tableau.
	 *
	 * @param mixed $offset
	 * @return boolean
	 */
	public function offsetExists($offset) {
		return array_key_exists($offset, $this->config);
	}

	/**
	 * Position à lire.
	 *
	 * @param string $offset
	 * @return mixed
	 */
	public function offsetGet($offset) {
		return array_key_exists($offset, $this->config) ? $this->config[$offset] : null;
	}

	/**
	 * Position à assigner.
	 *
	 * Cette fonction lève une WGSecurityException à chaque fois.
	 *
	 * @param mixed $offset
	 * @param mixed $value
	 * @throws WGSecurityException
	 * @return void
	 */
	public function offsetSet($offset, $value) {
		//$this->config[$offset] = $value;
		throw new WGSecurityException("Unauthorized");
	}

	/**
	 * Position à supprimer.
	 *
	 * Cette fonction lève une WGSecurityException à chaque fois.
	 *
	 * @param mixed $offset
	 * @throws WGSecurityException
	 * @return void
	 */
	public function offsetUnset($offset) {
		throw new WGSecurityException("Unauthorized");
	}

}

?>