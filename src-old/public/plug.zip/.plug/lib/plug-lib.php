<?php

define('SOHOPLUG_BASE', realpath(dirname(__FILE__) . '/../') . '/');
define('SOHOPLUG_WORKSPACE', realpath('.') . '/');
define('SOHOPLUG_VERSION', '5.0.1');

require_once SOHOPLUG_BASE . 'lib/common.php';
require_once SOHOPLUG_BASE . 'lib/class.softwarepackage.php';

class Soho_Plug {
	
	/**
	 * Configuration.
	 * @var null|boolean|string[]
	 */
	protected static $config = null;
	
	/**
	 * Session.
	 * @var null|string[]
	 */
	protected static $session = null;
	
	/**
	 * Initialisation du plug.
	 */
	public static function init() {
		
		// Chemin vers le fichier de configuration
		$inifile = SOHOPLUG_BASE . 'config/config.ini';
		
		// On vérifie que le fichier existe
		if (!is_file($inifile)) {
			throw new WGPlugException('Plug config.ini file not found');
		}
		
		// Lecture du fichier de configuration
		self::$config = @parse_ini_file($inifile, true);
		
		// On vérifie que le fichier ini soit valide
		if (!is_array(self::$config)) {
			throw new WGPlugException('Invalid plug config.ini file');
		}
		
	}

	/**
	 * @return string
	 */
	public static function getCurrentUser() {
		$session = self::getSessionData();
		if (!is_array($session)) return null;
		return $session['userName'];
	}
	
	public static function isLogged() {
		return self::getSessionData() !== null;
	}
	
	public static function getSessionData() {
		
		// Cache
		if (self::$session != null) {
			
			// Expiration
			
			// On renvoi la session en cache
			return self::$session;
			
		}
		
		// Chemin vers le fichier de la session
		$sessionfile = SOHOPLUG_BASE . 'config/.session';
		
		// Si la session n'existe pas, on renvoi null
		if (!is_file($sessionfile)) {
			return null;
		}
		
		// Lecture du fichier
		$fg = file_get_contents($sessionfile);
		
		// Erreur de lecture
		if (!$fg) {
			return null;
		}
		
		// Désérialisation
		$fg = unserialize($fg);
		
		// Erreur de désérialisation
		if (!is_array($fg)) {
			return null;
		}
		
		// Expiration
		if ($fg['datetime'] + intval(self::getConfig('Session', 'TTL')) < $_SERVER['REQUEST_TIME']) {
			return null;
		}
		
		return $fg;
		
	}
	
	protected static function getCookiesData($filterExpired = true, $filterHost = true) {
		
		// Chemin vers le fichier des cookies de libcurl
		$cookiefile = SOHOPLUG_BASE . 'config/.cookies';
		
		// Lecture du contenu du fichier de cookies
		$cookiedata = @file_get_contents($cookiefile);
		
		// Erreur
		if (!$cookiedata) {
			return array();
		}
		
		// Tableau de sortie
		$r = array();
		
		// Champs de chaque cookies
		$keys = array('host', 'secure', 'path', 'httponly', 'expires', 'name', 'value');
		
		// Pour le filtrage
		$host = self::getServerURL('host');
		$ttl = intval(self::getConfig('Session', 'TTL'));
		$expires = filemtime($cookiefile) + $ttl;
		
		// Lecture des lignes
		foreach (explode("\n", $cookiedata) as $line) {
			
			$line = trim($line);
			
			if (empty($line) || substr($line, 0, 1) == '#') continue;
			if (strpos($line, "\t") === false) continue;
			
			$cookie = array();
			$cookie = array_combine($keys, explode("\t", $line, 7));
			$cookie['secure'] = ($cookie['secure'] == 'TRUE');
			$cookie['httponly'] = ($cookie['httponly'] == 'TRUE');
			$cookie['expires'] = intval($cookie['expires']);
			
			if ($filterHost && $cookie['host'] !== $host) {
				continue;
			}
			
			if ($filterExpired) {
				if ($cookie['expires'] > 0) {
					if ($cookie['expires'] < $_SERVER['REQUEST_TIME']) {
						continue;
					}
				}
				else if ($cookie['expires'] === 0) {
					if ($expires < $_SERVER['REQUEST_TIME']) {
						continue;
					}
				}
			}
			
			$r[$cookie['name']] = $cookie;
			
		}
		
		return $r;
		
	}
	

	public static function getWorkspacePath() {
		return SOHOPLUG_WORKSPACE;
	}
	
	public static function getWorkspacePackagesList() {
		
		// Tableau de sortie
		$r = array();
		
		// On parcours les éléments du répertoire de workspace
		foreach (scandir(SOHOPLUG_WORKSPACE) as $item) {
			
			// On recupère le chemin vers l'élément
			$file = SOHOPLUG_WORKSPACE . $item . '/';
			
			// Sont considérés comme 'packages' les répertoires qui respectent la convention de nommage
			if (substr($item, 0, 1) == '.' || !fnmatch("*.*", $item)) continue;
			
			// On ne garde que les sous-dossiers
			if (!is_dir($file)) continue;
			
			// On recupère l'espace de nom, et le nom du package
			list($namespace, $name) = explode('.', $item, 2);

			// On ajoute le package dans la liste
			$r[$item] = array(
				'package.repository' => null,
				'package.folder' => "/$item/",
				'package.realpath' => $file,
				'package.namespace' => $namespace,
				'package.name' => $name
			);

		}
		
		return $r;
		
	}
	
	public static function getPackageByFullname($name) {
		
		$package = self::getWorkspacePackagesList();
		
		if (!array_key_exists($name, $package)) {
			return null;
		}

		require_once SOHOPLUG_BASE . 'lib/octophpus.php';
		
		return new Soho_SoftwarePackage($package[$name]);
		
	}
	
	public static function getServerURL($token = null) {
		
		if (!$token) {
			return self::$config['Repository']['URL'];
		}
		
		$url = parse_url(self::$config['Repository']['URL']);
		
		if (!is_array($url)) {
			return null;
		}

		return $url[$token];
		
	}
	
	public static function getConfig($category, $item) {
		return self::$config[$category][$item];
	}

	public static function logout() {
		
		// Logout local
		@unlink(SOHOPLUG_BASE . 'config/.cookies');
		@unlink(SOHOPLUG_BASE . 'config/.session');
		self::$session = null;
		
		// Logout remote
		self::executeRemoteRequest(
			array('ws' => 'auth', 'logout' => '1')
		);
		
	}
	
	public static function login($username, $password) {
		
		// Get SALT
		$salt = null;
		self::executeRemoteRequest(
			array('w' => 'auth', 'salt' => '1'),
			function ($data, $code) use (&$salt) {
				$salt = $data['salt'];
			}
		);
		
		// Check salt
		if (!is_string($salt)) {
			return 'unable to get salt';
		}
		
		$password = 'b:' .sha1($salt . ':' . sha1("$username:$password"));
		
		// Auth, and get session data
		$sessiondata = null;
		self::executeRemoteRequest(
			array(
				'w'												=> 'auth',
				self::getConfig('Session', 'LoginFieldName')	=> $username,
				self::getConfig('Session', 'PasswFieldName')	=> $password
			),
			function ($data, $code) use (&$sessiondata) {
				$sessiondata = $data;
			}
		);
		
		if (!is_array($sessiondata)) {
			return 'invalid user/password';
		}
		
		$sessiondata['datetime'] = $_SERVER['REQUEST_TIME'];
		
		return @file_put_contents(SOHOPLUG_BASE . 'config/.session', serialize($sessiondata)) !== false;
		
	}
	
	/**
	 * Télécharger un fichier et l'enregistre en local.
	 *
	 * Cette méthode utilise un fopen($filename, 'w') pour ouvrir le fichier $filename. Le fichier s'ouvre donc lecture,
	 * le curseur est placé au début du fichier et la taille du fichier est réduite à 0. Si le fichier n'existe pas,
	 * on tente de le créer. Cette opération peut échouer et lever une exception de type SubversionServerException.
	 *
	 * Notez aussi que cette méthode configure le temps d'exécution à l'infini maximale de PHP (set_time_limit) au $timeout
	 * plus 2 secondes. En CLI, cela n'a pas d'influence car cette configuration est bloquée à 0 (l'infini).
	 *
	 * Son considérés comme valables les codes HTTP de réponse allant de 200 (inclus) à 300 (non inclus).
	 *
	 * @param string $filename Chemin vers le fichier en local pour l'enregistrement.
	 * @param array $params Tableau de paramètres à envoyer en données POST au serveur.
	 * @param Closure|null $success Callback appelée en cas de réussite. Pour plus de détails, voir la méthode request().
	 * @param Closure|null $failure Callback appelée en cas d'erreur. Pour plus de détails, voir la méthode request().
	 * @param string|null $url URL vers le Webservice du serveur. S'il n'est pas précisé, l'URL renseignée au constructeur sera utilisée.
	 * @param string|null $progress Le nom de la fonction de callback qui sera appelée lors de la progression du téléchargement.
	 * 	La fonction de prend 3 paramètres : le premier est la ressource cURL, le second est la ressource de description de fichier,
	 *  et le troisième, est la longueur (int). Retourne la chaîne de caractères contenant les données.
	 * @param int $bufferSize La taille du buffer à utiliser pour chaque lecture. A utiliser avec une callback $progress pour
	 *  paramétrer la fréquence de rafraichissement. Cependant, la documentation de cURL pour PHP indique qu'il n'y a aucune
	 *  garantie que cette requête soit accomplie.
	 * @param timeout int La durée maximale en secondes que l'opération peut prendre. Au delà, elle sera interrompue.
	 *  Par défaut, cette valeur vaut 3600 (une heure).
	 * @return boolean Renvoi TRUE si l'opération est un succès et si les données sont bien enregistrées dans le fichier; ou
	 *  FALSE si une erreur survient. Pour une lecture plus précise de l'erreur, utiliser le callback $failure.
	 * @throws SubversionServerException S'il est impossible de créer ou de remplacer le fichier $filename.
	 */
	/*public function download($filename, $params, $success=null, $failure=null, $url=null, $progress=null, $bufferSize=2048, $timeout=3600) {
		// URL
		if (!$url) {
			$url = $this->url;
		}
		// Ouverture du fichier cible en écriture
		$fp = fopen($filename, 'w');
		if (!$fp) {
			throw new SubversionServerException('Unable to open: ' . $filename);
		}
		// Initialisation de la session
		$ch = curl_init();
		// Configuration des options
		curl_setopt($ch, CURLOPT_URL,				$url);
		curl_setopt($ch, CURLOPT_HEADER,			0);
		curl_setopt($ch, CURLOPT_POST,				1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION,	1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,	0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,	0);
		curl_setopt($ch, CURLOPT_TIMEOUT,			$timeout);
		curl_setopt($ch, CURLOPT_FILE,				$fp);
		curl_setopt($ch, CURLOPT_COOKIEJAR,			$this->cookiefile);
		curl_setopt($ch, CURLOPT_COOKIEFILE,		$this->cookiefile);
		curl_setopt($ch, CURLOPT_USERAGENT,			$this->useragent());
		curl_setopt($ch, CURLOPT_POSTFIELDS,		$params);
		// Progress callback
		if ($progress !== null) {
			curl_setopt($ch, CURLOPT_NOPROGRESS, false);
			curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, $progress);
			curl_setopt($ch, CURLOPT_BUFFERSIZE, $bufferSize);
		}
		// Exécution de la session
		set_time_limit($timeout + 2);
		$data = curl_exec($ch);
		// Récupération des données
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$statut = curl_errno($ch);
		$error = curl_error($ch);
		// Fermeture des ressources
		curl_close($ch);
		fclose($fp);
		// Event
		$this->trigger('download', array(
				'url' => $url,
				'params' => $params,
				'code' => $code,
				'statut' => $statut,
				'error' => $error,
				'type' => $type,
				'data' => $data
		));
		// Erreur
		if (($code < 200 || $code >= 300) || $statut !== 0) {
			if ($failure) {
				return $failure($code, $error, $statut, null) === true ? true : false;
			}
			return false;
		}
		// Success
		if ($success) {
			return $success($filename, $code) === false ? false : true;
		}
		return true;
	}*/
	
	/**
	 * Effectuer une requête au serveur.
	 *
	 * Cette méthode permet d'envoyer une requête au serveur pour
	 *
	 * Cette méthode est synchrone, c'est à dire qu'elle va bloquer l'éxecution du script jusqu'au bout de
	 * la communication avec le serveur.
	 *
	 * Si l'opération échoue, la callback $failure est lancée si elle est spécifiée. La closure
	 * peut avoir jusqu'à quatre arguments :
	 *  1) int $code : Le code de réponse HTTP renvoyé par le serveur.
	 *  2) string $error : Un message décrivant l'erreur.
	 *  3) string $statut : Le code de retour renvoyé par la fonction curl_errno().
	 *  4) string|array|null $data : Les données renvoyées par le serveur. Si le content-type de
	 *   la réponse est 'application/json' alors le client essayera automatiquement de décoder le
	 *   code JSON. Dans ce cas, $data sera un tableau (array). Si le code n'est pas valide, $data
	 *   sera renvoyé en text/plain sous forme de string.
	 *
	 * Si l'opération aboutie jusqu'au bout, la callback $success sera lancée si elle est spécifiée.
	 * La closure peut avoir juqu'à deux arguments :
	 *  1) string|array|null $data : Les données renvoyées par le serveur. Si le content-type de
	 *   la réponse est 'application/json' alors le client essayera automatiquement de décoder le
	 *   code JSON. Dans ce cas, $data sera un tableau (array). Si le code n'est pas valide, c'est
	 *   la callback $failure qui sera lancée.
	 *  2) int $code : Le code de retour HTTP.
	 *
	 * Notez aussi que cette méthode configure le temps d'exécution à l'infini maximale de PHP (set_time_limit) au $timeout
	 * plus 2 secondes. En CLI, cela n'a pas d'influence car cette configuration est bloquée à 0 (l'infini).
	 *
	 * Son considérés comme valables les codes HTTP de réponse allant de 200 (inclus) à 300 (non inclus).
	 *
	 * @param array $params Tableau contenant les paramètres à envoyer en POST au serveur.
	 * @param Closure|null $success Une callback qui sera lancée si l'action réussie.
	 * @param Closure|null $failure Une callback qui sera lancée en cas d'échec.
	 * @param string|null $url URL vers le Webservice du serveur. S'il n'est pas précisé, l'URL renseignée au constructeur sera utilisée.
	 * @param string|null $progress Le nom de la fonction de callback qui sera appelée lors de la progression du téléchargement.
	 * 	La fonction de prend 3 paramètres : le premier est la ressource cURL, le second est la ressource de description de fichier,
	 *  et le troisième, est la longueur (int). Retourne la chaîne de caractères contenant les données.
	 * @param int $bufferSize La taille du buffer à utiliser pour chaque lecture. A utiliser avec une callback $progress pour
	 *  paramétrer la fréquence de rafraichissement. Cependant, la documentation de cURL pour PHP indique qu'il n'y a aucune
	 *  garantie que cette requête soit accomplie.
	 * @param timeout int La durée maximale en secondes que l'opération peut prendre. Au delà, elle sera interrompue.
	 *  Par défaut, cette valeur vaut 3600 (une heure).
	 * @return boolean|mixed Renvoi TRUE si l'opération n'a produit aucune erreur. Pour plus de détails sur l'erreur,
	 *  utiliser le callback $failure. Le retour peut être overridé par les callbacks : si une callback est déclanchée
	 *  et qu'elle renvoi un résultat autre que NULL, celui-ci sera retransmis à la sortie de cette méthode.
	 */
	public static function executeRemoteRequest($params, $success=null, $failure=null, $url=null, $progress=null, $bufferSize=2048, $timeout=3600) {

		// URL
		if (!$url) {
			$url = self::getConfig('Repository', 'URL') . 'ws.php';
		}
		
		// Initialisation de la session
		
		$ch = curl_init();
		// Configuration des options
		curl_setopt($ch, CURLOPT_URL,				$url);
		curl_setopt($ch, CURLOPT_HEADER,			0);
		curl_setopt($ch, CURLOPT_POST,				1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION,	1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,	1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,	0);
		curl_setopt($ch, CURLOPT_TIMEOUT,			$timeout);
		curl_setopt($ch, CURLOPT_COOKIEJAR,			SOHOPLUG_BASE . 'config/.cookies');
		curl_setopt($ch, CURLOPT_COOKIEFILE,		SOHOPLUG_BASE . 'config/.cookies');
		//curl_setopt($ch, CURLOPT_USERAGENT,			$this->useragent()); // TODO
		curl_setopt($ch, CURLOPT_POSTFIELDS,		$params);
		
		// Progress callback
		if ($progress !== null) {
			curl_setopt($ch, CURLOPT_NOPROGRESS, false);
			curl_setopt($ch, CURLOPT_PROGRESSFUNCTION, $progress);
			curl_setopt($ch, CURLOPT_BUFFERSIZE, $bufferSize);
		}
		
		// Exécution de la requête
		set_time_limit($timeout + 2);
		$data = curl_exec($ch);
		
		// Récupération des données
		$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		$statut = curl_errno($ch);
		$error = curl_error($ch);
		$type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

		// Fermeture des ressources
		curl_close($ch);
		
		// Détermination du type mime
		if (is_string($type)) {
			$type = explode(';', $type);
			$type = array_shift($type);
		}
		else {
			$type = 'text/plain';
		}
		
		// Event
		/*$this->trigger('request', array(
				'url' => $url,
				'params' => $params,
				'code' => $code,
				'statut' => $statut,
				'error' => $error,
				'type' => $type,
				'data' => $data
		));*/
		
		// Erreur
		if (($code < 200 || $code >= 300) || $statut !== 0) {
			if ($failure) {
				// TODO Retirer cette partie au profit de la lecture du message dans les headers
				// JSON decode
				if ($type === 'application/json') {
					$tmp = @json_decode($data, true);
					// Erreur dans le decodage du JSON
					if ($tmp === null) {
						$error = 'invalid json error';
					}
					// Lecture du message d'erreur
					else {
						if (isset($tmp['error'])) {
							$error = $tmp['error'];
						}
						$data = $tmp;
					}
				}
				// Clean
				unset($tmp);
				// Callback
				$r = $failure($code, $error, $statut, $data);
				if ($r === null) { // automatic
					return false;
				}
				return $r;
			}
			return false;
		}
		
		// Success
		if ($success) {
			// JSON decode
			if ($type === 'application/json') {
				$tmp = @json_decode($data, true);
				// Erreur dans le decodage du JSON
				if ($tmp === null) {
					if ($failure) {
						$r = $failure($code, 'invalid json', 'success', $data);
						if ($r === null) { // automatic
							return false;
						}
						return $r;
					}
					return false;
				}
				else {
					$data = $tmp;
				}
				// Clean
				unset($tmp);
			}
			// Callback
			$r = $success($data, $code);
			if ($r === null) { // automatic
				return true;
			}
			return $r;
		}
		//echo $data;
		return true;
	}
	
}

class WGPlugException extends WGException { }

Soho_Plug::init();

?>