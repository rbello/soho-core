<?php

class Soho_Plug_CLI extends Soho_CLI {
}

?>