<?php

include dirname(__FILE__) . '/www/index.php';

?>